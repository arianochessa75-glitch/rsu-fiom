/* =====================================================================
   CONTENUTI DEL SITO RSU FIOM
   Questo è l'UNICO file da modificare per aggiornare il sito.
   Non serve toccare index.html.

   COME SI FA
   1. Metti i file nelle cartelle accanto a index.html:
        documenti/   -> PDF, Word, Excel        (es. documenti/accordo-2026.pdf)
        video/       -> video MP4 (se non usi YouTube/Vimeo)
        immagini/    -> foto e locandine (JPG, PNG)
   2. Aggiungi una riga nella zona giusta qui sotto.
   3. Ricarica la cartella su Netlify (Deploys > trascina la cartella).

   ATTENTI ALLE VIRGOLE: ogni voce dell'elenco finisce con una virgola,
   tranne l'ultima. Le scritte vanno tra apici '...'. Se nel testo c'è un
   apostrofo scrivilo così:  l\'azienda

   ALLEGATI: si possono mettere in bacheca e nei documenti. Tipi:
     {tipo:'pdf',      file:'documenti/nome.pdf', etichetta:'Scarica il PDF'}
     {tipo:'pdf',      file:'documenti/nome.pdf', anteprima:true}   <- PDF letto direttamente nella pagina
     {tipo:'video',    url:'https://www.youtube.com/watch?v=XXXXXXXXXXX'}   <- YouTube o Vimeo
     {tipo:'video',    file:'video/assemblea.mp4'}                  <- video caricato da te
     {tipo:'immagine', file:'immagini/locandina.jpg', alt:'Descrizione'}
     {tipo:'link',     url:'https://...', etichetta:'Apri il sito'}
     {tipo:'pagina',   pagina:'guida-permessi', etichetta:'Leggi la guida'}  <- pagina interna del sito
   ===================================================================== */

window.CONTENUTI = {

  /* ------------------------------------------------------------------
     FOGLIO GOOGLE (gestione comoda da telefono, senza ricaricare il sito)
     Incolla qui tra apici il link del foglio "pubblicato sul web" in
     formato CSV. Le righe che scrivi nel foglio compaiono sul sito da sole
     e si sommano a quelle di questo file. Vuoto = nessun foglio.
     ------------------------------------------------------------------ */
  foglio: '',

  /* ------------------------------------------------------------------
     INTRO AUDIO (all'apertura della home, una volta a visita)
     attivo: true/false  -> accende o spegne l'intro
     durata: secondi (da 3 a 12); l'audio sfuma e si spegne da solo
     file:   '' = suono creato dal sito (colpi di martello e accordo)
             oppure un tuo MP3, es. 'audio/intro.mp3' (cartella audio/)
     Nota: i telefoni e i browser bloccano i suoni che partono da soli,
     quindi all'apertura compare una schermata con il pulsante
     "Entra nel sito": toccandolo parte l'audio.
     ------------------------------------------------------------------ */
  intro: {attivo: true, durata: 5, file: ''},

  /* ------------------------------------------------------------------
     TESTI LIBERI
     Lascia '' per non mostrare nulla.
     ------------------------------------------------------------------ */
  testi: {
    // Paragrafo in più sotto "Benvenuti nel sito della RSU" (home)
    benvenuto: '',
    // Paragrafo in più nella pagina "Chi siamo" (storia della RSU, quanti delegati siete...)
    chiSiamo: '',
    // Pagina Contatti, riquadro "Dove trovarci" (sede e orari). Se vuoto il riquadro non compare.
    sede: ''
  },

  /* ------------------------------------------------------------------
     BACHECA
     Le più recenti in alto. pinned:true = fissata in alto.
     date: anno-mese-giorno.   tag: categoria (es. 'Comunicazione',
     'Assemblea', 'Sicurezza', 'Accordo'). Quando ci sono più categorie
     compaiono da sole i filtri.
     testo: per andare a capo lascia una riga vuota (\n\n).

     MODELLO DA COPIARE:
     {date:'2026-10-15', tag:'Assemblea', pinned:false,
      title:'Titolo dell\'avviso',
      testo:'Testo dell\'avviso.',
      allegati:[
        {tipo:'pdf', file:'documenti/volantino.pdf', etichetta:'Scarica il volantino'},
        {tipo:'video', url:'https://www.youtube.com/watch?v=XXXXXXXXXXX'}
      ]},
     ------------------------------------------------------------------ */
  bacheca: [
    {
      date: '2026-09-30', tag: 'Comunicazione', pinned: true,
      title: 'Richiesta di incontro con l\'Azienda',
      testo: 'Come previsto dall\'accordo integrativo aziendale, la RSU ha chiesto alla Direzione Risorse Umane un incontro su: andamento delle attività, inquadramento del personale, ferie residue degli anni precedenti, portale ZConnect e workflow, lavoratori somministrati, relazioni con le rappresentanze sindacali, riscaldamento nei luoghi di lavoro in vista dell\'inverno, gestione dei distributori automatici, sicurezza nei luoghi di lavoro e prevenzione. L\'incontro è previsto a fine ottobre: siamo in attesa di data e ora. Dopo l\'incontro faremo un\'assemblea per riferire quanto discusso.',
      allegati: []
    },
    {
      date: '2026-09-28', tag: 'Comunicazione', pinned: true,
      title: 'Dal 1° ottobre permessi e ferie con l\'app ZConnect',
      testo: 'Le richieste di permessi e ferie si fanno da smartphone con l\'app ZConnect oppure da computer. Trovi la guida passo passo nella pagina Documenti.',
      allegati: [
        {tipo: 'pagina', pagina: 'guida-permessi', etichetta: 'Leggi la guida'},
        {tipo: 'pdf', file: 'documenti/richiesta-permessi-zconnect.pdf', etichetta: 'Scarica il PDF'}
      ]
    }
  ],

  /* ------------------------------------------------------------------
     DOCUMENTI
     Gruppi (cat) con dentro le voci. Un gruppo senza voci non compare.
     Puoi aggiungere, togliere o rinominare i gruppi.

     MODELLO DA COPIARE (dentro items:[ ... ]):
     {t:'Nome del documento', d:'Breve descrizione o data',
      allegati:[ {tipo:'pdf', file:'documenti/nome.pdf'} ]},

     Per un video nella sezione Video:
     {t:'Titolo del video', d:'Di cosa parla',
      allegati:[ {tipo:'video', url:'https://www.youtube.com/watch?v=XXXXXXXXXXX'} ]},
     ------------------------------------------------------------------ */
  documenti: [
    {
      cat: 'Guide',
      items: [
        {
          t: 'Richiesta permessi e ferie con l\'app ZConnect',
          d: 'In vigore dal 1° ottobre 2026',
          allegati: [
            {tipo: 'pagina', pagina: 'guida-permessi', etichetta: 'Leggi la guida'},
            {tipo: 'pdf', file: 'documenti/richiesta-permessi-zconnect.pdf', etichetta: 'Scarica il PDF'}
          ]
        },
        {
          t: 'Calcolatore ferie anno precedente (AP)',
          d: 'Parti dalla busta di dicembre e scopri quante ferie dell\'anno precedente ti restano davvero, con guida passo passo',
          allegati: [
            {tipo: 'pagina', pagina: 'calcolatore-ferie', etichetta: 'Apri il calcolatore'}
          ]
        }
      ]
    },
    {
      cat: 'Leggi e contratti',
      items: [
        {
          t: 'Statuto dei lavoratori',
          d: 'Legge 20 maggio 1970, n. 300: il testo ufficiale su Normattiva',
          allegati: [{tipo: 'link', url: 'https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:legge:1970-05-20;300', etichetta: 'Leggi il testo'}]
        },
        {
          t: 'CCNL Unionmeccanica Confapi PMI',
          d: 'Contratto nazionale per la piccola e media industria metalmeccanica, orafa e installazione di impianti (testo del 26 maggio 2021, dal sito Fiom)',
          allegati: [{tipo: 'link', url: 'https://www.fiom-cgil.it/piccole-e-medie-imprese/ccnl-unionmeccanica', etichetta: 'Leggi il contratto'}]
        },
        {
          t: 'Rinnovo del CCNL 2025-2028',
          d: 'Ipotesi di accordo del 4 giugno 2026, approvata dai lavoratori con la consultazione conclusa il 23 luglio 2026',
          allegati: [{tipo: 'link', url: 'https://www.fiom-cgil.it/piccole-e-medie-imprese/trattativa-pmi', etichetta: 'Vai alla pagina Fiom'}]
        }
      ]
    },
    { cat: 'Accordi aziendali',      items: [] },
    { cat: 'Volantini e comunicati', items: [] },
    { cat: 'Moduli',                 items: [] },
    { cat: 'Video',                  items: [] }
  ],

  /* ------------------------------------------------------------------
     DELEGATI (pagina Chi siamo)
     foto: percorso di un'immagine (es. 'immagini/alessandro.jpg').
     Se vuoto compaiono le iniziali. telefono: facoltativo.

     MODELLO:
     {nome:'Cognome Nome', ruolo:'Delegato RSU', reparto:'Reparto', telefono:'', foto:''},
     ------------------------------------------------------------------ */
  delegati: [
    {nome: 'Ariano Alessandro', ruolo: 'RSU RLS', reparto: 'Rappresentante dei Lavoratori per la Sicurezza', telefono: '', foto: ''}
  ],

  /* ------------------------------------------------------------------
     COME AIUTIAMO (pagina Come aiutiamo): riquadri dei temi
     ------------------------------------------------------------------ */
  servizi: [
    {titolo: 'Busta paga',              testo: 'Controllo di voci, straordinari, permessi e differenze.'},
    {titolo: 'Orari e turni',           testo: 'Turni, ferie, permessi e riposi.'},
    {titolo: 'Salute e sicurezza',      testo: 'Segnalazioni, DPI, infortuni e rischi in reparto.'},
    {titolo: 'Contratto di lavoro',     testo: 'Inquadramento, livelli, contratto nazionale e accordi aziendali.'},
    {titolo: 'Malattia e infortunio',   testo: 'Cosa fare e quali tutele hai.'},
    {titolo: 'Problemi con l\'azienda', testo: 'Contestazioni, trasferimenti e altre situazioni difficili.'}
  ],

  /* ------------------------------------------------------------------
     DOMANDE FREQUENTI
     Una domanda con la risposta vuota ('') NON compare sul sito:
     scrivi la risposta e comparirà.
     vai: facoltativo, aggiunge un link a una pagina del sito
          (home, bacheca, chi-siamo, servizi, documenti, enti, contatti)
     ------------------------------------------------------------------ */
  faq: [
    {d: 'Come posso parlare con un delegato?',
     r: 'Chiama o scrivi al numero indicato nella pagina Contatti, oppure cerca un delegato in reparto.'},
    {d: 'Quello che dico resta riservato?',
     r: ''},
    {d: 'Come mi iscrivo al sindacato?',
     r: ''},
    {d: 'Dove trovo gli accordi aziendali?',
     r: 'Gli accordi aziendali sono raccolti nella pagina Documenti.',
     vai: {pagina: 'documenti', etichetta: 'Apri Documenti'}}
  ]
};
